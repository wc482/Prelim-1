% Compute the scaled state sensitivity coefficients as a function of time
s1=sensitivity_P1(A,S,x);
s2=sensitivity_P2(A,S,x);

% Approximate the integrals in the time-averaged sensitivity array using 
% the trapezoidal rule
M1=trapz(s1,2)/450;
M2=trapz(s2,2)/850;

% Construct the time-averaged sensitivity array for Phase I
N1=zeros(3,6);
N1(:,1)=M1(1:3,1);
N1(:,2)=M1(4:6,1);
N1(:,3)=M1(7:9,1);
N1(:,4)=M1(10:12,1);
N1(:,5)=M1(13:15,1);
N1(:,6)=M1(16:18,1);

% Construct the time-averaged sensitivity array for Phase II
N2=zeros(3,6);
N2(:,1)=M2(1:3,1);
N2(:,2)=M2(4:6,1);
N2(:,3)=M2(7:9,1);
N2(:,4)=M2(10:12,1);
N2(:,5)=M2(13:15,1);
N2(:,6)=M2(16:18,1);

% Rank-order the importance of model species using Singular Value
% Decomposition (SVD) of the time-averaged sensitivity array(s) for 
% Phase 1, and early/late Phase 2. Use the absolute magnitude of the first
% column of the U matrix as the basis for ranking in each of the 3 time
% windows (Phase 1, early Phase 2, and late Phase 2)

[U1,S1,V1]=svd(N1);
[U2,S2,V2]=svd(N2);

