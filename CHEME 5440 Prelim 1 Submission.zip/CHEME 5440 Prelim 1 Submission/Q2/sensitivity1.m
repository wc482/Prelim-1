function [p1,p2,p3]=sensitivity1(A,S,t_Initial,t_Final,a,b,c,d,e,f)

pd=-log(0.5)/(60*24);                      % protein degradation constant
L(1)=1200; L(2)=2400; L(3)=600;            % Given gene lengths [nt]
xd=-log(0.5)/2.1;                          % mRNA degradation rate constant
N_A=6.022*10^23;                           % Avogadro's Number 

% Plasmid concentration convert [copies/cell] to [nmol/gDW]
p_conc=200/N_A*10^9/((2.8e-13)*0.3);     

% RNAP concentration convert [copies/cell] to [nmol/gDW]
RNAP_conc=1150/N_A*10^9/((2.8e-13)*0.3)*a;

% Ribosome concentration convert [copies/cell] to [nmol/gDW]
ribosome_conc=45000/N_A*10^9/((2.8e-13)*0.3)*b; 

e_x=60*60;
ke1=e_x*c/L(1); % Elongation rate constant kel
tau1=ke1/20;

ke2=e_x/L(2);
tau2=ke2/20;

ke3=e_x/L(3);
tau3=ke3/20;

K_x=0.24*e;         %dissociation constant of RNAP [nmol/gDW]
K_L=454.64*f;       %dissociation constant of ribosome [nmol/gDW]
n=1.5;
Kd=0.3;             %dissociation constant of inducer [mM]

x=zeros(6,t_Final);

for t=t_Initial:t_Final

% Formulate the binding functions (Moon/Voigt Model)
f2=x(4,t)^n/(1000^n+x(4,t)^n);
f13=x(4,t)^n/(1000^n+x(4,t)^n);
f23=x(5,t)^10/(100000^10+x(5,t)^10);

% Control function terms (Moon/Voigt Model)
u2=(0.0000001+10*f2)/(1+0.0000001+10*f2);
u3=(0.0000001+5*f13+25*f23)/(1+0.0000001+5*f13+25*f23);

% Transcription
tx1=(RNAP_conc*ke1/tau1*(p_conc/(p_conc+K_x)));
tx2=(RNAP_conc*ke2/tau2*(p_conc/(p_conc+K_x)))*u2;
tx3=(RNAP_conc*ke3/tau3*(p_conc/(p_conc+K_x)))*u3;

% Translation
tl1=x(1,t)*ribosome_conc/K_L*(16.5*60*d/L(1)*3);
tl2=x(2,t)*ribosome_conc/K_L*(16.5*60*d/L(2)*3);
tl3=x(3,t)*ribosome_conc/K_L*(16.5*60*d/L(3)*3);

r=[tx1;tx2;tx3;tl1;tl2;tl3];
x(:,t+1)=expm(A*1)*x(:,t)+inv(A)*[expm(A*1)-eye(6)]*S*r;
end

%Protein P1, P2, P3
p1=x(4,400:450);
p2=x(5,400:450);
p3=x(6,400:450);
end