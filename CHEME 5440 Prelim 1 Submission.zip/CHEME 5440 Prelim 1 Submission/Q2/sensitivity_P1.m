function s1=sensitivity_P1(A,S,x)
% Phase 1

% To compute the scaled state sensitivity coefficients, the scale factor 
% and the partial derivative need to be calculated and multiplied together.

% Computational implementation hint/trick: When computing the sensitivity 
% coefficients for small state (i.e. concentration) values (e.g. during the
% window we add inducer) we typically (artificially) neglect the scaling
% term (set to 1). This may be an issue depending on upon the values of Wjj
% that are chosen. 

% Increase the RNAP concentration by a factor of 10
[p1,p2,p3]=sensitivity1(A,S,1,650,10,1,1,1,1,1);
N_A=6.022*10^23;                                       %Avogadro's Number
conversion = N_A*10^9/((2.8e-13)*0.3);

partial_derivp_a1=(p1-x(4,400:450))./(1150/conversion);
scaling_factor_a1=1150/conversion./x(4,400:450);
sssc_a1=scaling_factor_a1.*partial_derivp_a1;

partial_derivp_a2=(p2-x(5,400:450))./(1150/conversion);
scaling_factor_a2=1150/conversion./x(5,400:450); 
sssc_a2=scaling_factor_a2.*partial_derivp_a2;

partial_derivp_a3=(p3-x(6,400:450))./(1150/conversion);
scaling_factor_a3=1150/conversion./x(6,400:450); 
sssc_a3=scaling_factor_a3.*partial_derivp_a3;

% Increase the ribosome concentration by a factor of 10
[p1,p2,p3]=sensitivity1(A,S,1,650,1,10,1,1,1,1);

partial_derivp_b1=(p1-x(4,400:450))./(45000/conversion);
scaling_factor_b1=45000/conversion./x(4,400:450); 
sssc_b1=scaling_factor_b1.*partial_derivp_b1;

partial_derivp_b2=(p2-x(5,400:450))./(45000/conversion);
scaling_factor_b2=45000/conversion./x(5,400:450); 
sssc_b2=scaling_factor_b2.*partial_derivp_b2;

partial_derivp_b3=(p3-x(6,400:450))./(45000/conversion);
scaling_factor_b3=45000/conversion./x(6,400:450); 

sssc_b3=scaling_factor_b3.*partial_derivp_b3;

% Increase the transcription factor elongation rate by a factor of 10
[p1,p2,p3]=sensitivity1(A,S,1,650,1,1,10,1,1,1);

partial_derivp_c1=(p1-x(4,400:450))./(3600*9);
scaling_factor_c1=3600./x(4,400:450); 
sssc_c1=scaling_factor_c1.*partial_derivp_c1;

partial_derivp_c2=(p2-x(5,400:450))./(3600*9);
scaling_factor_c2=3600./x(5,400:450); 
sssc_c2=scaling_factor_c2.*partial_derivp_c2;

partial_derivp_c3=(p3-x(6,400:450))./(3600*9);
scaling_factor_c3=3600./x(6,400:450); 

sssc_c3=scaling_factor_c3.*partial_derivp_c3;

% Increase the translation elongation rate by a factor of 10
[p1,p2,p3]=sensitivity1(A,S,1,650,1,1,10,1,1,1);

partial_derivp_d1=(p1-x(4,400:450))./(16.5*60*9);
scaling_factor_d1=16.5*60./x(4,400:450); 
sssc_d1=scaling_factor_d1.*partial_derivp_d1;

partial_derivp_d2=(p2-x(5,400:450))./(16.5*60*9);
scaling_factor_d2=16.5*60./x(5,400:450); 
sssc_d2=scaling_factor_d2.*partial_derivp_d2;

partial_derivp_d3=(p3-x(6,400:450))./(16.5*60*9);
scaling_factor_d3=16.5*60./x(6,400:450); 

sssc_d3=scaling_factor_d3.*partial_derivp_d3;

% Increase the translation elongation rate by a factor of 10
[p1,p2,p3]=sensitivity1(A,S,1,650,1,1,10,1,1,1);

partial_derivp_d1=(p1-x(4,400:450))./(16.5*60*9);
scaling_factor_d1=16.5*60./x(4,400:450); 
sssc_d1=scaling_factor_d1.*partial_derivp_d1;

partial_derivp_d2=(p2-x(5,400:450))./(16.5*60*9);
scaling_factor_d2=16.5*60./x(5,400:450); 
sssc_d2=scaling_factor_d2.*partial_derivp_d2;

partial_derivp_d3=(p3-x(6,400:450))./(16.5*60*9);
scaling_factor_d3=16.5*60./x(6,400:450); 

sssc_d3=scaling_factor_d3.*partial_derivp_d3;

% Increase Kx by a factor of 10
partial_derivp_e1=(p1-x(4,400:450))./(0.24*9);
scaling_factor_e1=0.24./x(4,400:450); 
sssc_e1=scaling_factor_e1.*partial_derivp_e1;

partial_derivp_e2=(p2-x(5,400:450))./(0.24*9);
scaling_factor_e2=0.24./x(5,400:450); 
sssc_e2=scaling_factor_e2.*partial_derivp_e2;

partial_derivp_e3=(p3-x(6,400:450))./(0.24*9);
scaling_factor_e3=0.24./x(6,400:450); 

sssc_e3=scaling_factor_e3.*partial_derivp_e3;

% Increase KL by a factor of 10
partial_derivp_f1=(p1-x(4,400:450))./(454.64*9);
scaling_factor_f1=454.64./x(4,400:450); 
sssc_f1=scaling_factor_f1.*partial_derivp_f1;

partial_derivp_f2=(p2-x(5,400:450))./(454.64*9);
scaling_factor_f2=454.64./x(5,400:450); 
sssc_f2=scaling_factor_f2.*partial_derivp_f2;

partial_derivp_f3=(p3-x(6,400:450))./(454.64*9);
scaling_factor_f3=454.64./x(6,400:450); 

sssc_f3=scaling_factor_f3.*partial_derivp_f3;

s1=vertcat(sssc_a1,sssc_a2,sssc_a3,sssc_b1,sssc_b2,sssc_b3,sssc_c1,sssc_c2,sssc_c3,sssc_d1,sssc_d2,sssc_d3,sssc_e1,sssc_e2,sssc_e3,sssc_f1,sssc_f2,sssc_f3);
 
end