% Maximize the translation rate (v5) for I = 0.0001 mM to I = 10.0
% mM. Let W1 = 0.26, W2 = 300.0, K = 0.30 mM and n = 1.5. Plot the steady-state
% protein level versus inducer concentration I on a semilogx scale

tau1=2.7;                           % time constant for transcription
tau2=0.8;                           % time constant for translation
K_x=0.3;                            % dissociation constant of RNAP in microM
K_L=57;                             % dissociation constant of ribosome in microM
xd=8.35;                            % mRNA degradation rate constant [h^-1]
N_A=6.022*10^23;                    % Avogadro's Number
pd=9.9*10^(-3);                     % [h^-1]
p_conc=5*10^(-3);                   % Plasmid concentration [microM]
RNAP_conc=0.15;                     % RNAP concentration [microM]
ribosome_conc=1.6;                  % ribosome concentration in microM
e_x=60*3600;
ke1=e_x/924;                        % Enlongation rate constant ke 

Stoichiometric_Matrix =[
    -1 1 0 0 0 0 0 0 0 0 0 0 0 0 0;        %G
    -1 1 0 0 0 0 0 0 0 0 0 0 0 0 0;        %RNAP
    1 -1 0 0 0 0 0 0 0 0 0 0 0 0 0;        %G*
    0 -924 0 0 0 0 0 1 0 0 0 0 0 0 0;        %NTP
    0 1 -1 -1 1 0 0 0 0 0 0 0 0 0 0;       %mRNA
    0 1848 0 0 616 2 0 0 0 0 0 0 0 0 -1;      %Pi
    0 0 924 0 0 0 0 0 0 -1 0 0 0 0 0;        %NMP
    0 0 0 -1 1 0 0 0 0 0 0 0 0 0 0;        %rib
    0 0 0 1 -1 0 0 0 0 0 0 0 0 0 0;        %rib*
    0 0 0 0 -308 1 0 0 0 0 0 0 0 0 0;        %AAtRNA
    0 0 0 0 -616 0 0 0 0 0 0 0 1 0 0;       %GTP
    0 0 0 0 308 -1 0 0 0 0 0 0 0 0 0;        %tRNA
    0 0 0 0 616 0 0 0 0 0 0 0 0 -1 0;       %GDP
    0 0 0 0 1 0 0 0 -1 0 0 0 0 0 0;        %protein
    0 0 0 0 0 -1 1 0 0 0 0 0 0 0 0;        %AA
    0 0 0 0 0 -1 0 0 0 0 1 0 0 0 0;        %ATP
    0 0 0 0 0 1 0 0 0 0 0 -1 0 0 0;        %AMP
    0 0 0 0 0 0 -1 0 0 0 0 0 0 0 0;        %AAext
    0 0 0 0 0 0 0 -1 0 0 0 0 0 0 0;        %NTPext
    0 0 0 0 0 0 0 0 1 0 0 0 0 0 0;         %proteinext
    0 0 0 0 0 0 0 0 0 1 0 0 0 0 0;         %NMPext
    0 0 0 0 0 0 0 0 0 0 -1 0 0 0 0;        %ATPext
    0 0 0 0 0 0 0 0 0 0 0 1 0 0 0;         %AMPext
    0 0 0 0 0 0 0 0 0 0 0 0 -1 0 0;        %GTPext
    0 0 0 0 0 0 0 0 0 0 0 0 0 1 0;         %GDPext
    0 0 0 0 0 0 0 0 0 0 0 0 0 0 1];        %Piext

% Expression for the rate of transcription based on Moon/Voigt formulation
r_x=RNAP_conc*ke1/tau1*(p_conc/(p_conc+K_x));

syms v1 v2 v3 v4 v5 v6 b1 b2 b3 b4 b5 b6 b7 b8 b9

% Vector containing the rate constants
F=[v1;v2;v3;v4;v5;v6;b1;b2;b3;b4;b5;b6;b7;b8;b9];
S1=sym(Stoichiometric_Matrix);
sv=S1*F;

%Lower bounds are different for b1-b9 due to reaction reversibility
lower_bound=[0,0,0,0,0,0,-100000,-100000,-100000,-100000,-100000,-100000,-100000,-100000,-100000];
f=[0 0.52 0 0 0 0 0 0 0 0 0 0 0 0 0];

protein=zeros(1000,1);
Inducer=zeros(1000,1);
for i=1:1000
    f1=(i/100)^1.5/(0.3^1.5+(i/100)^1.5);
    u1=(0.26+300*f1)/(1+0.26+300*f1);
    mRNA=r_x*u1/xd;
    
% Expression for translation upper bound based on Moon/Voigt formulation
R5_Upper_Bound=16.5*3600/300*1.6*0.8*(mRNA/(57+mRNA));
upper_bound=[1000,50,10,1000,R5_Upper_Bound,10,100000,100000,100000,100000,100000,100000,100000,100000,100000];

x=linprog(-f,[],[],Stoichiometric_Matrix,zeros(1,26),lower_bound,upper_bound);
protein(i)=x(2);
Inducer(i)=i/100;
end

semilogx(Inducer,protein,'LineWidth',2);
xlabel('Inducer Concentration [mM]');
ylabel('Protein Level');